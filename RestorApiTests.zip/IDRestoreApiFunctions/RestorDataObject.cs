﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoreApiFunctions
{
    public class RestoreDataObject
    {
        public int TempHigh1 { get;  set; }
        public BoilerState State { get; set; }
        public int TempHigh2 { get;  set; }
    }
}
